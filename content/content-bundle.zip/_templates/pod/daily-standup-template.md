---
title: "Currently Working on..."
sleep: 
tags: 
- 'pod/daily/{{date:YYYY}}/{{date:MM}}/{{date:DD}}'
date created: Tuesday, November 8th 2022, 3:13:21 pm
date modified: Wednesday, November 9th 2022, 8:31:42 am
---

## Currently Working on...

## Worked On, Recently completed...

## Notes

## Meetings

| With who | When | What for |
| --- | ---- | -------- |
|     |      |          |