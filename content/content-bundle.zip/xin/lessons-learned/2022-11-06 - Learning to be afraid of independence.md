---
title: "2022-11-06 - Learning to be afraid of independence"
tags: 
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:41 am
---

Whenever we think about someone moving out of their parents’ homes, starting their own lives, working their first big job, and becoming financially independent - we applaud them, we welcome them into society, we deem them as adults, we look up to them, and we take them as inspirations.

I always looked up to these people, I yearned for independence. Since I was young, I never wanted anything to do with my family. I tried so hard in school to prove to myself that I don’t need anyone other than myself to suceed. I fought against myself to prove this point. Every time I achieved something great, I thought to myself, “my parents are going to realize, ‘Xin really doesn’t need us to succeed’.”

Looking back, I was so naive. All my family cared for was my happiness and my wellbeing. My grades? That wasn’t even in their concern. What they wanted was a son to spend time with, a son they can live happily with - day by day.

Now that I have achieved all of this independence and all of this “success” that we, together, as society denote - I learned that all I ever wanted was the childhood I once had. I wish I can have the same butterflies in my stomach when I asked for that $20 to see a movie, or to hang out with my friends after school, or to buy some snacks from the ice cream truck.

I hate being independent. I wish I learned this earlier.