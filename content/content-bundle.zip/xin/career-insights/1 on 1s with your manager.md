---
title: "What to Talk About During 1:1s"
tags: 
- xin/career-advice
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:42 am
---

[TOC]

[[__TOC__]]

[[_TOC_]]

{{toc}}

[/toc/]

[]()**Table of Contents**

1. [[#What Not to Talk About During 1:1s|What Not to Talk About During 1:1s]]
1. [[#A Good Template to Follow|A Good Template to Follow]]
	1. [[#A Good Template to Follow#Highlights From the Last Week|Highlights From the Last Week]]
	1. [[#A Good Template to Follow#Issues|Issues]]
	1. [[#A Good Template to Follow#Deliverables|Deliverables]]
	1. [[#A Good Template to Follow#Topics / Updates / Questions|Topics / Updates / Questions]]
		1. [[#Topics / Updates / Questions#Feedback (live feedback)|Feedback (live feedback)]]


## What to Talk About During 1:1s

- Long term vision of your career and how to get there, make a plan with your manager for this
- Short term goals, whether there are any blockers stopping you to achieve them
- Things you found challenging in past days and how did you solve them
- Feedback, get immediate feedback from your manager around events in past days and also give it to them
- I also like to talk about stuff outside work with my reports, travel, etc

## What Not to Talk About During 1:1s

- Reporting status on your work, its not a standup meeting or a status check meeting

## A Good Template to Follow

### Highlights From the Last Week

- _Short, 1-5 bullet updates on what is going well, including at least one personal thing_
- _This is a good convo-starter especially if you're remote and 1:1s feel more formal_

### Issues

- _Short, 1-5 bullet summary of the toughest problems you are facing right now_
- _Whenever you bring up a problem, try to present solutions to react to_

### Deliverables

- From last 1:1
	- _Copy/paste the previous week’s section on “Deliverables to next meeting”, then cross off those that were completed. For those not completed, explain why and either agree to deprioritize or roll into this week’s “Deliverables to next meeting”_
- To next 1:1
	- _Fill in the things that need to be accomplished before the next meeting_
	- _Include any action items or follow-ups generated during the 1:1_
	- _Roll forward any remaining follow-up items_

### Topics / Updates / Questions

==Aim to spend most of the time on topics and questions; best opportunity to learn==

#### Feedback (live feedback)

> Might feel like overkill to do this weekly, BUT it de-stigmatizes feedback and you'll never be surprised in a performance review. By including positive AND constructive feedback, you get a healthy mix of things that make you feel good and opportunities to do better.

- ##### From manager to you
	- **Like**
		- _Something your manager likes about working with you. Could be praise for a strength, kudos on an action, or anything else._
		- _Specific feedback / examples > general statements_
	- **Wish that**
		- _Best to share constructive feedback in-person_
		- _Also important to document feedback for future reference. Many people find it best to write out constructive feedback before the meeting in a separate document, and then paste it in during the 1:1_
		- _Specific feedback / examples > general statements_
- ##### **From you to manager**
	- **Like**
		- _Something you like about working with your manager_
	- **Wish that**
		- _Something you wish your manager would do differently_

