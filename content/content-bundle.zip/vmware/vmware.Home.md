---
title: "vmware.Home"
tags: 
date created: Tuesday, November 8th 2022, 2:57:22 pm
date modified: Wednesday, November 9th 2022, 8:31:35 am
---

[Personal Space - Confluence](https://jira.eng.vmware.com/secure/Dashboard.jspa?selectPageId=61316)

[CDS Dashboard - Jira](https://jira.eng.vmware.com/secure/Dashboard.jspa?selectPageId=61316)


```todoist
{
"name": "pod: today & overdue",
"filter": "(P:pod* & today),(P:pod* & overdue), (@pod & today), (@pod & overdue)"
}
```