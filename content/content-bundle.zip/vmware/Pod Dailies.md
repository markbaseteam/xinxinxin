---
title: "Pod Dailies"
tags: 
date created: Tuesday, November 8th 2022, 10:17:16 pm
date modified: Wednesday, November 9th 2022, 8:37:07 am
---

## 2022

### November

```dataview
Table sleep, tags
From #pod/daily/2022/11
SORT file.name DESC
```

### October

```dataview
Table sleep, tags
From #pod/daily/2022/10 
SORT file.name DESC
```