## RTS stands for "Remediation and Troubleshooting Services"
- Note that Optimus has RTS button
![](TOI%20for%20RTS%20Script,%2010.27.2022/AA9F4FE3-0DF9-439B-9ED6-FBEF3C137DA6.png)
- There are scripts that takes in inputs, goes to sddc, and helps other pagers resolve issues
- Example: RDU Upgrade takes 5 minutes
![](TOI%20for%20RTS%20Script,%2010.27.2022/2F3F69A0-CCC9-4D74-8879-FC71F2B5E8CF.png)
- If something goes wrong, we want to simply cancel the upgrade through a script, remediating the problem in the SDDC
- Possible task: performing the RDU Upgrade and get it into a state that fails

#pod/topic/rts-scripts
#pod/2022/10/27