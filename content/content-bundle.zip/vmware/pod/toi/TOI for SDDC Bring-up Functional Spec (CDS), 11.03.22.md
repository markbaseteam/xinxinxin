---
title: "TOI for SDDC Bring-up Functional Spec (CDS), 11.03.22"
tags:
  - pod/update_on_confluence
  - pod/2022/11/03
  - pod/topic/sddc-bringup
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:32:56 am
---

## Why CDS?

[Reference](https://confluence.eng.vmware.com/pages/viewpage.action?pageId=1075560187)

- VMware has released numerous solutions in prior years in order to combine all of the compute, storage, and network products together to build and operate SDDCs (software-defined data center)
	- Though the solutions are built on the same VMware products, each has built a custom orchestration for bringup, day-0 configurations, day-N operations such as expand/shrink cluster, and etc.
	- Cloud Domain Service (CDS) is our proposed project in which aims to create a service that can build and operate SDDCs to be leveraged by all of VMware's solutions
	- This solution enables integration of a product/feature into CDS to be shared across all of VMware's solutions, standardizes the core configuration, provides ownership and agility for the product teams to build and evolve the operators

### What is an SDDC?

- A software-defined data center is a data storage facility in which all infrastructure elements: network, storage, cpu, security, are virtualized and delivered as a service (SDDCaaS)

![[TOI for SDDC Bring-up Functional Spec (CDS), 11.03.22_image_1.png]]

![[TOI for SDDC Bring-up Functional Spec (CDS), 11.03.22_image_2.png]]

## SDDC Bringup Using CDS for VMC on AWS

### What is SDDC Bringup?

[Reference](https://confluence.eng.vmware.com/display/CDSP/Func+Spec%3A+SDDC+Bringup+Using+CDS+for+VMC+on+AWS)

- SDDC Bringup is the process in which bootstraps the management appliances and configures the SDDC Management Cluster after the ESX hosts are provisioned

### Workflow

#### Existing Workflow

![[TOI for SDDC Bring-up Functional Spec (CDS), 11.03.22_image_3.png]]

#### CDS Bringup Workflow

![[TOI for SDDC Bring-up Functional Spec (CDS), 11.03.22_image_4.png]]

- As you can see above, instead of directly communicating to SDDC vCenter and ESX through the proxy, the CDS bringup workflow communicated through the CDS agent container, which then relays the necessary information to the necessary components
- This allows us to keep majority of our codebase the same while allowing us to provision the additional layer and steps needed for the CDS Agent Container
