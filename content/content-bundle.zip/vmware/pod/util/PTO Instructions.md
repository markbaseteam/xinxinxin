---
title: "PTO Instructions"
tags:
  - pod/onboarding
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:22:59 am
---
1. E-mail Nora to request PTO for dates
2. Once approved, update status here: [PTO Link](https://confluence.eng.vmware.com/display/POD/Pod+Team)
3. Make sure Outlook has automated response
4. Make sure Slack status reflects PTO
