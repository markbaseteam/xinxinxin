---
title: "Important Sites"
tags:
  - pod/onboarding
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:35 am
---

- Search VMware Internal Jargons: <http://wtf.eng.vmware.com/> For example, you can search VC, DBC etc. acronyms and find out what that means.
- Useful dev utility tool like JWT decode, File Diff, JSON Formatter etc. : <https://dev-utils.svc.eng.vmware.com/jwt-decode>
- VMC site to deploy and manage SDDC: <https://vmc.vmware.com>, <https://stg.skyscraper.vmware.com/>
- AWS site to access the AWS EC2, S3 instances: [console.aws.amazon.com](http://aws.amazon.com/) → <https://127776885678.signin.aws.amazon.com/console>
- CSP service portal for support or account issues: <https://csp-jira.eng.vmware.com/servicedesk/customer/portal/3/create/31>
- Optimus for operator access: <https://sre.vmc.vmware.com/vmc/sre/ui/search>, <https://stg-int.skyscraper.vmware.com/vmc/sre/ui/>
- RCE: <https://internal.vmc.vmware.com/vmc/rc/ui/overview>, <https://int-stg-us-west-2.skyscraper.vmware.com/vmc/rc/ui/overview>
- Config Service: <https://internal.vmc.vmware.com/vmc/cs/ui/configs>, <https://int-stg-us-west-2.skyscraper.vmware.com/vmc/cs/ui/configs>
- RLCM: <https://internal.vmc.vmware.com/vmc/uoe/ui/rlcm/rollout-deployments>, <https://int-prd-us-west-2.vmc.vmware.com/vmc/uoe/ui/rlcm/rollout>
- Git: [Gitlab.eng.vmware.com/](http://gitlab.eng.vmware.com/)
- OpenGrok for SDDC components code search, mostly used for perforce code search: <https://opengrok.eng.vmware.com/source/> . Select project main.perforce.1666 for pod code.
- VMC Nitros Quota: <http://lms-vm.eng.vmware.com/>, [https://qms-jenkins.svc.eng.vmware.com/view/Team Usage/job/LMS_VIEW_TEAM_USAGE_DETAILS](https://qms-jenkins.svc.eng.vmware.com/view/Team%20Usage/job/LMS_VIEW_TEAM_USAGE_DETAILS)
- VMC Nimbus Quota: <https://vmcnimbus.eng.vmware.com/home/nimbusstatistics/quotamanagement>
- Nimbus FAQ: [VMC Nimbus Frequently Asked Questions](https://confluence.eng.vmware.com/display/VMCLifeCycleBLR/VMC+Nimbus+Frequently+Asked+Questions)
