---
title: "Pod-Service Docker Image (M1 Architecture)"
tags:
  - pod/reference
  - pod/topic/m1-architecture
date created: Tuesday, November 8th 2022, 12:46:10 pm
date modified: Wednesday, November 9th 2022, 8:10:42 am
---

[Dockerfile](https://vmware.enterprise.slack.com/files/WBWKR52UU/F046Z9HCVQV/dockerfilem1.txt?origin_team=T024JFTN4&origin_channel=Psearch)

```
FROM harbor-repo.vmware.com/dockerhub-proxy-cache/amd64/photon:3.0-20220128
WORKDIR /usr/lib/vmware-pod
# Python Dependencies
RUN tdnf install -y shadow diffutils build-essential python3-pip python3-setuptools python3-tools
RUN tdnf install -y vim
RUN tdnf install -y sudo
RUN tdnf install -y coreutils
RUN groupadd -r pod && useradd -r -u 1001 -g pod pod
COPY requirements.txt .
RUN pip3 install --upgrade --no-cache-dir pip
RUN pip3 install --no-cache-dir --requirement requirements.txt
# Source code
COPY build/pod-rpm/usr/lib/vmware-pod/resource ./resource
RUN chown -R pod:pod ./resource
COPY build/pod-rpm/usr/lib/vmware-pod/vapi ./vapi
RUN chown -R pod:pod ./vapi
COPY build/pod-rpm/usr/lib/vmware-pod/lib ./lib
RUN chown -R pod:pod ./lib
COPY build/pod-rpm/usr/lib/vmware-pod/firstboot ./firstboot
RUN chown -R pod:pod ./firstboot
COPY build/pod-rpm/usr/lib/vmware-pod/bin ./bin
RUN chown -R pod:pod ./bin
COPY build/pod-rpm/usr/lib/vmware-pod /usr/lib/vmware
RUN chown -R pod:pod /usr/lib/vmware
COPY build/pod-rpm/storage/vmware-pod /storage/vmware-pod
RUN chown -R pod:pod /storage/vmware-pod
COPY build/pod-rpm/etc/vmware /etc/vmware
RUN chown -R pod:pod /etc/vmware
COPY build/pod-rpm/etc/vmware-pod /etc/vmware-pod
RUN chown -R pod:pod /etc/vmware-pod
COPY build/pod-rpm/var/vmware-pod/scripts /var/vmware-pod/scripts
RUN chown -R pod:pod /var/vmware-pod/scripts
RUN cat vapi/metadata/pod_cli.json | grep service_id | tr -cd '[[:alnum:].:_\n]' > vapi/metadata/authz.ini
COPY build/pod-rpm/usr/lib/vmware-pod/py/driver ./py/driver
RUN chown -R pod:pod ./py/driver
COPY build/pod-rpm/usr/lib/vmware-pod/py/vmware ./py/vmware
RUN chown -R pod:pod ./py/vmware
COPY build/pod-rpm/usr/lib/vmware-pod/py/workflow ./py/workflow
RUN chown -R pod:pod ./py/workflow
COPY build/pyVpx/pyVpx /usr/lib/vmware/pyVpx
RUN chown -R pod:pod /usr/lib/vmware/pyVpx
COPY build/vsanmgmtObjects.py /usr/lib/vmware/pyVpx/
RUN chown -R pod:pod /usr/lib/vmware/pyVpx/
# Enable create session with no auth
RUN sed -i 's/\[\"UsernamePasswordScheme\"\]/\[\"NoAuthentication\"\]/' vapi/metadata/pod_authentication.json
RUN sed -i 's/identity\.get_username()/\"root\"/' py/vmware/session_impl.py
COPY cloud-domain-service.launcher ./
RUN chmod +x ./cloud-domain-service.launcher
EXPOSE 5680
CMD ["./cloud-domain-service.launcher"]
ARG version
LABEL pod.version="${version}"
```