---
title: "Markdown to Confluence (Markup) Converter"
tags:
  - pod/2022/11/03
  - pod/utilities
date created: Tuesday, November 8th 2022, 12:46:10 pm
date modified: Wednesday, November 9th 2022, 8:31:35 am
---

## Install Ruby

```
brew install rbenv ruby-build

# list latest stable versions
rbenv install --list

rbenv install <version-number>
rbenv global <version-number>
```

- Depending on your shell, `echo $SHELL`, you may need to manually append rbenv into your shell configuration file.
	- For bash: `echo 'eval "$(~/.rbenv/bin/rbenv init - bash)"' >> ~/.bashrc`
	- For zsh: `echo 'eval "$(~/.rbenv/bin/rbenv init - zsh)"' >> ~/.zshrc`
- Make sure these are appended to the end of your shell configuration

```
...
eval "$(rbenv init - zsh)"
eval "$(~/.rbenv/bin/rbenv init - zsh)"
```

> Follow <https://www.jedi.be/blog/2011/12/15/markdown-to-confluence-conversion/>

- Install gem package:
	- `gem install markdown2confluence`
- Use tool through `markdown2confluence <filename.md>`

