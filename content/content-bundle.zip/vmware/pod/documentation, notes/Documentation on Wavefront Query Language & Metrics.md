---
title: "Documentation on Wavefront Query Language & Metrics"
tags:
  - pod/topic/alerts/wavefront
  - pod/topic/alerts/metrics
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:39 am
---

- [Query language tutorial](https://docs.wavefront.com/query_language_getting_started.html)
- **Metrics measure what is going on**
- **Queries help visualize that information**

![[Documentation on Wavefront Query Language & Metrics_image_1.png]]

- Wavefront is all about querying time series data and alerting at the appropriate time
- Start with query editor or chart editor

[Wavefront language document api](docs.wavefront.com)

- Use advanced functions to help find problem, behavior, or pattern of metric
  - Set one metric as base and then query against base

![](Documentation%20on%20Wavefront%20Query%20Language%20&%20Metrics/ACEF6260-F0FA-4D18-8BE8-A5073F4AE397.png)

## Query Syntax

- **Time series** measures a particular phenomenon over time
- Example:
  - time series: temperature
  - values: ear, forehead
- Each query has the following components. Only the metric is required, the other elements are optional, but they help you get the information you’re really interested in.
- A **metric** (or a constant, such as `10`). Above, the metric is temperature. In this example, the metric is `~sample.cpu.loadavg.1m`
- One or more **sources**. Above, sources would have been patients. Here, sources could be the host, VM, container, etc. In this example, the source is `app-*` – that means metrics that come from `db-*` are ignored.
- One or more point tags. Above, we have the `location` point tag - `ear` and `forehead`. In this example, we have the `env` point tag with value `production`. Only valid point tags can be queried.
- One or more functions. This example uses the `avg()` function, and the `mmedian()` function with a 10-minute time window. The [Query Language Reference](https://docs.wavefront.com/query_language_reference.html) lists each function with a short description and points to reference pages.

Here’s how the same query looks in the Query Editor:
![[Documentation on Wavefront Query Language & Metrics_image_2.png]]
