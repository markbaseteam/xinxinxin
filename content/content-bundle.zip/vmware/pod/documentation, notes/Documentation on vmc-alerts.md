---
title: "Documentation on Vmc-alerts"
tags:
  - pod/topic/alerts/wavefront
  - pod/topic/alerts/metrics
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:39 am
---

<https://gitlab.eng.vmware.com/vmc/vmc-alerts>

<https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/overview.md>

<https://gitlab.eng.vmware.com/vmc/vmc-alerts/blob/master/CODEOWNERS>

> CODEOWNERS README provides examples of various alerts, and includes examples of directories where our team has made changes

# Documentation on Vmc-alerts

/alerts/apps/sddc-worker/ @PodService

/alerts/tests/sddc-worker/ @PodService

/v2/alerts/pod-service/ @PodService

# Workload Impact Alerts

/alerts/apps/workload-impact-detection/ @PodService

/alerts/tests/workload-impact-detection/ @PodService

/v2/alerts/workload-impact-detection/ @PodService

## AAC: Alerts as Code

- Framework that lets service owners define their wavefront (commercial), lint, elastic search (govcloud), and event alerting service (EAS) as configurations as associated test data
- **AACv2** provides improved usability, extensibility, and multi-tenant support
- Standardizes alert from across alert sources and automated production push process

## AAC Structure

- `v2/alerts/{team_assignee}/.../{alert_name}/`
  - `alert.json` - alert definition
  - `tests.json` - test payloads for this alert

## AAC Dashboard

- `v2/dashboards/{owner_team}/.../{dashboard_name}/`
  - `dashboard.json` - dashboard definition

> Read into pagerduty integration\
> <https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/pd-service-creation.md>

## Multi-tenancy

- Alerts and dashboards are enabled for **all** vmc tenants by default
- If required, each alert or dashboard could be enabled in specific tenants / enabled everywhere but select tenants
- Controlled through fields `validForTenants` and `skipForTenants`
- Select values like team assignee and pagerduty key can also be overidden for specific tenants
- ![[Documentation on vmc-alerts_image_1.png]]

---

## Starting with AAC

- AAC is a framework provide scripts to perform user tasks: importing new alerts, testing alerts, etc
- scripts are located in `devops/scripts`

> AACv2 scripts get credentials to Wavefront, LINT and ElasticSearch from Vault. In order to access these credentials, scripts will need to obtain a Vault token. The script requires LDAP credentials. Please set the env variables to your LDAP credentials `AAC_USERNAME` and `AAC_PASSWORD`.

## AACv2 Flows

### Defining a New Alert

> Read this in detail later when developing new alerts

[Developing new alerts](https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/developing-new-alerts.md)

- Create the alert in dev environment using the UI
- Use script to import it into AAC directory structure

[Event alerting service (EAS) alert creation](https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/developing-new-alerts.md#event-alerting-service-eas-alert-creation)

[Wavefront and LINT Alert creation in UI](https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/developing-new-alerts.md#wavefront-and-lint-alert-creation-in-ui)
