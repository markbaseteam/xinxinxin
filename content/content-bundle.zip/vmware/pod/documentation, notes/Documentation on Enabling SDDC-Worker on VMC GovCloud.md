---
title: "Documentation on Enabling SDDC-Worker on VMC GovCloud"
tags: 
- pod/topic/sddc-worker
- pod/topic/govcloud
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:39 am
---

[[Notes on Enabling SDDC-Worker for x86 Architecture]]

[[Documentation for SDDC-Worker With VMware Horizon Cloud Host Setup (M1 Architecture)]]

- [Obtain access to VMC services to debug sddc-worker on gov cloud staging](https://confluence.eng.vmware.com/display/POD/Obtain+access+to+VMC+services+to+debug+sddc+worker+on+gov+cloud+staging)
- Gov cloud Backend and Autoscaler URL : [https://stg-us-gov-west-1.skyscraper.vmware.com/console/sddcs](https://stg-us-gov-west-1.skyscraper.vmware.com/console/sddcs)
- Gov cloud CSP : [https://console-stg.us-gov.cloud.vmware.com](https://console-stg.us-gov.cloud.vmware.com/)
- Gov cloud Optimus : [https://int-stg-us-gov-west-1.skyscraper.vmware.com/vmc/sre/ui/search](https://int-stg-us-gov-west-1.skyscraper.vmware.com/vmc/sre/ui/search) (edited)

## TOI

Zoom meeting : [https://VMware.zoom.us/rec/share/3T-tIZ-bJz6a9WBemHj1o0a2MZyan9dLyOCejl-Nk7IemJnQF5MDtm24lYPcJ2KX.ryFa1IhCfHIxksCf](https://vmware.zoom.us/rec/share/3T-tIZ-bJz6a9WBemHj1o0a2MZyan9dLyOCejl-Nk7IemJnQF5MDtm24lYPcJ2KX.ryFa1IhCfHIxksCf)

Passcode: 85W!Txe! (edited)

## Resources

[skyscraper-stg gov-cloud232.postman_environment.json](https://res.craft.do/user/full/36499dbb-58b8-75f1-bb54-c749a2e2fe80/doc/E4DB4DB5-F17E-4DB5-97DF-BE796076643F/4460DB65-3AC1-48B2-8C87-CE1257ABA9D0_2/iB4M0s2qmBCA2Akd8MgIdorweQxJIKRa3P7UD5DVVzQz/skyscraper-stg%20gov-cloud232.postman_environment.json)

```other
Jianping Yang
  5:32 PM
I can add you in. Which roles do you need?


Rohith H Y
  5:32 PM
operator-rw
5:33
"perms": [
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/dimension-operator:operations",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:rts-ro",
    "external/7cJ2ngS_hRCY_bIbWucM4KWQwOo_/log-intelligence:user",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:brs-ro",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:ro",
    "csp:org_member",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:rce-admin",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:brs-rw",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:rts-rw",
    "external/ybUdoTC05kYFC9ZG560kpsn0I8M_/vmc-operator:da-rw"
  ],
5:33
Actually the above ones


Rohith H Y
12:46 PM
Hi Jianping, Im not able to access optimus : https://int-stg-us-gov-west-1.skyscraper.vmware.com/vmc/sre/ui/search
12:47 PM
Can you help me out please?
It got stuck for a few minutes and then gave this error {"error_code":"skyscraper.internal.error.default","error_messages":["An internal error has occurred."],"retryable":false,"status":500,"path":"/vmc/rts/auth/oauth"} (edited)
```