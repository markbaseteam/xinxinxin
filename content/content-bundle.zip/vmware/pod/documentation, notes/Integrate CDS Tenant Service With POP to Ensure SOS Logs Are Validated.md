---
title: "Integrate CDS Tenant Service With POP to Ensure SOS Logs Are Validated"
tags:
  - pod/topic/pop
  - pod/topic/logs
  - pod/2022/09/31
date created: Tuesday, November 8th 2022, 12:46:10 pm
date modified: Wednesday, November 9th 2022, 8:32:18 am
---

## Useful Commands

- `ssh -i sshkey vmc-xwang3@pop.sddc-44-227-130-145.vmwarevmc.com`
- `scp -i ~/Desktop/pop-ssh.pem cds.tgz vmc-xwang3@<pop_url>:/home/vmc-xwang3`
- `docker save cloud-domain-service:latest | gzip > cds.tgz`

### Ideas to Try

- `docker run -d --name cloud-domain-service --env VMW_POD_CDS=true --net internal -p 127.0.0.1:5680:5680 -v /pop:/pop cloud-domain-service:latest`
- **Script to make sure that our logs are present in resultant bundle**
- `/opt/vmware/sddc-support/sos`

## Lessons Learned

**Docker**

- Volume mounts occur only at container creation time. Meaning we can't change volume mounts after we've started the container. Volue mounts are one-way only: from the **host** to the **container**, not vice versa.
- When we specify a host directory mounted as a volume in your container (for example something like: `docker run -d --name="foo" -v "/path/on/host:/path/on/container" ubuntu`), it means that the host directory will temporarily "override" the container directory.
- Nothing is actually deleted or overwritten on the destination directory, but because of the nature of containers, that effectively means it will be overridden for the lifetime of the container.

## Links

[pod-service](https://gitlab.eng.vmware.com/cloud-domains/pod-service)

[Ankit's commit that onboarded CDS tenant service to POP](https://gitlab.eng.vmware.com/vmc/ss-pop-service/-/blob/master/saltstack/srv/salt/pop/services/tenant_services/tenant_services_config/docker.cloud-domain-service/docker.cloud-domain-service.service)

<https://gitlab.eng.vmware.com/cloud-domains/pod-service/-/blob/main/wsgi.properties>

## Goals

- Follow up with Yufeng to discuss how we can make this happen
- Standard docker mount `docker.cloud-domain-service.service` in ss-pop-service so that logs are shared to `/pop/log/pod-service`
- Ultimately what we want is that when the sos logs are bundled, our logs are included in the bundle
- Configure our logs to also point to the same directory

## What Worked?

- When comparing the docker service file it is just a longer docker run command appended with a mount from /pop on our container to host

```other
docker run -d --name cloud-domain-service --env VMW_POD_CDS=true --net internal -p 127.0.0.1:5680:5680 -v pod-service:/pop cloud-domain-service:latest
```

- Starting a docker volume with this command essentially mounted `/pop` on our container to a volume `pod-service` on the host
	- Even if our container is removed, the data remains on the host machine
	- We want to directly mount to the host machine

### Bind Mounts

- In the case of bind mounts, the first field is the path to the file or directory on the **host machine**. The second field is the path where the file or directory is mounted in the container.

```other
docker run -d --name cloud-domain-service --env VMW_POD_CDS=true --net internal -p 127.0.0.1:5680:5680 -v /pop:/pop cloud-domain-service:latest
```

![[Integrate CDS Tenant Service With POP to Ensure SOS Logs Are Validated_image_1.png]]

- Seems like when we mount over `/pop`, when we go into sudo mode we overwrite `/pop` on the host machine and our logs become visible
- When we mount it like this our container files are stored in `/root/pop` whereas the original files are stored at /pop

## Notes

### Yufeng

- A couple of services generates log files so they are included in the SOS bundle. Most of the tenant services just log to stdout through docker and they are streamed to the log service (logz or LINT). Is it good enough? If you want logs to be part of the SOS bundle, you will need to generate log files and manage them (log rotation).
- It is just standard docker volume mount. You can take a look at our s3-adapter.
	- [VMware Code Scout](https://codescout.eng.vmware.com/home/explorerepo/blob/@latest/vmc.ss-pop-service.master/saltstack/srv/salt/pop/services/tenant_services/tenant_services_config/docker.pop-s3-adapter/docker.pop-s3-adapter.service)
	- It saves the logs to /pop/log/s3-adapter

### Uday

- specifically mentioning about -v /pop:/pop
	- so the docker container is mounting the POP folder and directly writing log files to it, we can do the same
	- mount that directory and just configure our logger (Rohith's change) to write to this directory
- sure..we might be missing some config things and end to end..but you can start with this and see..basically you should see the logs on the po when we write them from container
- also i see some permission things here: <https://opengrok.eng.vmware.com/source/xref/vmc-ss-pop-service-git/saltstack/srv/salt/pop/ami_creator/initial_configuration.sls#32>
- <https://opengrok.eng.vmware.com/source/xref/vmc-ss-pop-service-git/saltstack/srv/pillar/pop/properties.sls#75>
