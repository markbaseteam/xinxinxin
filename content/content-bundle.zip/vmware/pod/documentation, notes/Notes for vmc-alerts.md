---
title: "Notes for vmc-alerts"
tags:
- pod/topic/alerts
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:38 am
---

- <https://gitlab.eng.vmware.com/vmc/vmc-alerts>
- <https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/overview.md>
- <https://gitlab.eng.vmware.com/vmc/vmc-alerts/blob/master/CODEOWNERS>

> CODEOWNERS readme provides resources to examples for @PodService

## AAC: Alerts as Code

### Overview

Alerts can come from a variety of sources. These sources fall into 3 categories: time series-based, log-based and event-based. These categories are described below.

#### Time Series

Time series data means that the data is in a series of particular time periods or intervals. Time series metrics allow to apply a number of functions to the data and alert when the result reaches certain threshold(s). In VMC, time series-based sources are:

- Wavefront - supported in AACv1 and AACv2 in Commercial only
- ElasticSearch (ES) - supported in AACv2 in GovCloud only

#### Logs

Logs-based source systems provide an ability to alert when certain logs show up or a number of specific logs per interval is beyond a certain threshold. In VMC, logs-based sources are:

- vRealize Log Insight (LINT) - supported in AACv1 and AACv2
- Logz.io - supported in AACv1 in Commercial only

### AAC Structure

- `v2/alerts/{team_assignee}/.../{alert_name}/`
- `alert.json` : Alert definition
- `tests.json` : Test payloads for this alert

### AAC Dashboard

- `v2/dashboards/{owner_team}/.../{dashboard_name}/`
- `dashboard.json` - dashboard definition

> Read into pagerduty integration <https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/pd-service-creation.md>

### AAC Vs. AAC2?

- **AACv2** provides improved usability, extensibility, and multi-tenant support
- It standardizes alert from across alert sources and automated production push process

### Multi-tenancy

- Alerts and dashboards are enabled for **all** vmc tenants by default
	- If required, each alert or dashboard could be enabled in specific tenants / enabled everywhere but select tenants
		- Controlled through fields `validForTenants` and `skipForTenants`
	- Select values like team assignee and pagerduty key can also be overriden for specific tenants
![](Notes%20for%20vmc-alerts/9C098940-9430-43FD-BEAC-B9AFCA739A07.png)

### Starting with AAC

- Framework provide scripts to perform user tasks such as importing new alerts, testing alerts, etc.
- scripts are located in `devops/scripts`

> AACv2 scripts get credentials to Wavefront, LINT and ElasticSearch from Vault. In order to access these credentials, scripts will need to obtain a Vault token. The script requires LDAP credentials. Please set the env variables to your LDAP credentials `AAC_USERNAME` and `AAC_PASSWORD`.

### AACv2 Flows

#### Define a New Alert

> Read this in detail when creating new alerts later

- Create the alert in dev environment using the UI
- Use script to import it into AAC directory structure
- [Developing New Alerts](https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/developing-new-alerts.md)
- [Event Alerting Service (EAS) Alert Creation](https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/developing-new-alerts.md#event-alerting-service-eas-alert-creation)
- [Wavefront and LINT Alert creation in UI](https://gitlab.eng.vmware.com/vmc/vmc-alerts/-/blob/master/v2/docs/developing-new-alerts.md#wavefront-and-lint-alert-creation-in-ui)
