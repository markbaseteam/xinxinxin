---
title: "Python"
tags:
- pod/topic/m1-architecture
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:40 am
---

- Follow the steps here first: [Remote development on a remote linux virtual machine](https://confluence.eng.vmware.com/display/~cyixing/Remote+development+on+a+remote+linux+virtual+machine)
- Login to VMware Horizon Cloud Host with this server <https://sjc-horzion.vmware.com>
  - If you receive the following error where VM access was granted through AccessNow but upon clicking the VM prompts “This desktop is being maintained. Please try again later.”
  - ![[Documentation for SDDC-Worker With VMware Horizon Cloud Host Setup (M1 Architecture)_image_1.png]]
- Resolution: Contacted Oasis for a ticket to be created, issue was resolved the next business day

---

> First, SSH into your local VM, then we have to update and match our dependencies

# Python

> Here, I matched the versions between my local VM and dbc for dependencies needed for the build since sddc-worker was able to compile successfully on my dbc

- Find out current python version: `python --version`
- We want python version of 3.9.
  - If python 3.9 is installed on system but `python --version` outputs the wrong version, symlink python to python3: `sudo apt-get install python-is-python3 -y`

> The more proper way is to use a virtual environment that manages python versions, but I wanted to just ensure that sddc-worker can successfully build

- pyyaml version must be 5.4.1 to avoid errors for `:generateSwaggerCodeSddcworker:`
- Check version `pip show pyyaml`, if the version is > 5.4.1:

```
sudo apt uninstall 
sudo apt install pyyaml==5.4.1
```

---

# Java

- Find out current Java version: `java -version/show-version`
- Set Java version to 1.8.0
  - `sudo update-java-alternatives --list`
- If Java version 1.8 does not exist, run the following command: `sudo apt-get update && sudo apt install openjdk-8-jdk`
- `sudo update-alternatives --config java`
- Select the corresponding Java: `/usr/lib/jvm/java-8-openjdk-amd64/jre/bin/java`

![[Documentation for SDDC-Worker With VMware Horizon Cloud Host Setup (M1 Architecture)_image_2.png]]

- Verify your Java version is correct by running: `java -version`

1. Setup proper git lab access
2. Setup docker
   - <https://www.linuxtechi.com/how-to-install-rancher-on-ubuntu/>
   - <https://linuxhostsupport.com/blog/how-to-install-and-configure-docker-compose-on-ubuntu-20-04/>
3. Clone <https://gitlab.eng.vmware.com/vmc/sddc-worker> and follow README

---

# Other Issues Faced

- If encountered JVM space exhausted related issues:
- Refer to <https://stackoverflow.com/questions/53854198/jvm-space-exhausted-when-building-a-project-through-gradle>
- I modified `./gradle-wrapper.properties` in `/home/<username>/projects/sddc-worker/gradle/wrapper` to include

```other
org.gradle.daemon=true
org.gradle.jvmargs=-Xmx2560m
```