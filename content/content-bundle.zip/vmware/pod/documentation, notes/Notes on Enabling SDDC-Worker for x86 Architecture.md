---
title: "Notes on Enabling SDDC-Worker for x86 Architecture"
tags:
  - pod/topic/sddc-worker
  - pod/2022/10/31
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:31:38 am
---

[[Documentation for SDDC-Worker With VMware Horizon Cloud Host Setup (M1 Architecture)]]

* Python version needed is 3.9
	* Install [miniconda3](https://docs.conda.io/en/latest/miniconda.html)
	* `conda create --name py39 python=3.9`
	* `conda activate 39`
* Requires pyyaml package 5.4.1
	* `pip3 install pyyaml==5.4.1`

- Java version needed is java8
	- `brew tap adoptopenjdk/openjdk`
	- `brew install openjdk@8`
	- `export JAVA_HOME=$(/usr/libexec/java_home -v1.8)`
- `brew install docker-compose`
- Make sure docker/rancher is running
- Make sure python environment is activated
- Clone sddc-worker and run local script
	- May need to provide read/write/execute access before running
- If using rancher, make sure docker-compose symlink points here:
	- `~/.rd/bin/docker-compose`
	- `ln -sfn ~/.rd/bin/docker-compose ~/.docker/cli-plugins/docker-compose`
- If using docker, symlink here:
	- `/usr/local/opt/docker-compose/bin/docker-compose `
	- `ln -sfn /usr/local/opt/docker-compose/bin/docker-compose ~/.docker/cli-plugins/docker-compose`

## Blockers

### Kubernetes in Rancher Fails to Initialize Through Proxy

- It seems that Rancher is getting continuously stuck when trying to initiate and setup. All the docker commands were hanging in my terminal, and it seems the Rancher's proxy is refusing to initiate and connect.
- I'm running this with moby/dockerd. Previously, I was able to get the docker command working once - but my terminal ended up hanging, and `docker-compose-down` was stuck indefinitely. I've tried pruning all of my containers, images, and volumes but that led to more containers snapping back to one another, since then - I've been blocked at this issue.

* Resolution:
	* Reached out to Rohith, Linshan, and Helen for guidance on issue
	* Resolved by disabling kubernetes in Rancher app settings, build necessary images, and then re-enabling kubernetes in app settings

### Operator Refresh Token Fails to Authorize in Ss-be

- Linshan recommended API call for Operator Token

```
POST http://localhost:8000/csp/gateway/am/api/login

body: raw json

{“username”:“[operator@vmware.com](mailto:operator@vmware.com)”,“password”:“VMware@123", “cspRoles”: [“csp:org_owner”], “vmcRoles”: [“vmc-operator:rw”, “vmc-operator:sensitive”]}
```

```json
{
  "username":"operator@vmware.com",
  "password":"VMware@123",
  "cspRoles":["csp:org_owner"],
  "vmcRoles":["vmc-operator:rw", "vmc-operator:sensitive"]
}
```

![](vmware/pod-attachments/7E3C2950-C660-404E-A843-D6C355F02AE4.png)

- Authentication is set as basic authentication
- Talk to Linshan about the exact token we need
	- Try different refresh token, operator refresh token, staging refresh token

### Ensure All Environment Exports Are Accurate

- Finding system-ip
	- Mac: System settings -> Network -> Find on your network connection -> Details -> IP Address

### Make Sure You Are Added to SDDC-WORKER-STG VMC Environment

::**SDDC-Worker API Token** (SDDC-WORKER-STG)::

 `Qv6Q2O5Bl9xhOwJSYasBl7gU0X_LyDcyAaK2YcD42nPk6vRt5kr2gdE7eZjmfgpP`
