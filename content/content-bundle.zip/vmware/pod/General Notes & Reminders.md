---
title: "General Notes & Reminders"
tags: 
date created: Tuesday, November 8th 2022, 12:46:11 pm
date modified: Wednesday, November 9th 2022, 8:34:09 am
---

## Python Unit Testing, DBC

- When unit-testing: `export VMW_SOURCE="/dbc/sc-dbc2145/xwang3/P4/xwang3_bazel_main/"` is aliased as `evs`
- Ticket for intel mac: <https://help.vmware.com/ticket/TKT6141599>

## Resources

- [[Important Sites]]
- [[PTO Instructions]]

## Notes

- `/mts/scratch/xwang3`
  - Directory inside dbc that allows for remote storage

## SDDC-Worker System IP Address

- `export SERVER_HOST=[IPv4 from Mac System Settings -> Network]*c*`
