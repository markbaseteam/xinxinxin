---
title: "Notes for Dockers & Containers"
tags:
  - status/on-hold
date created: Tuesday, November 8th 2022, 12:46:10 pm
date modified: Wednesday, November 9th 2022, 8:31:41 am
---

[The differences between Docker, containerd, CRI-O and runc - Tutorial Works](https://www.tutorialworks.com/difference-docker-containerd-runc-crio-oci/?_hsmi=213803458&_hsenc=p2ANqtz-9sG2sEhcUMQjT6TP2afLdek9j75SQpLmTYqiaty0XaVOl_Gr9r8yS5Fo1XgrSvvIgYpuBWcGIvQ62JC5fALOApvt_wiw#understanding-docker)
