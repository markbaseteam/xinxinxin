---
title: "Pod Weekly Status Reports"
tags: 
date created: Tuesday, November 8th 2022, 12:46:10 pm
date modified: Wednesday, November 9th 2022, 8:29:39 am
---

## 11.04.22

- Resolved blocker regarding kubernetes not initializing through Rancher proxy
	- [[Notes on Enabling SDDC-Worker for x86 Architecture]]
- [[CDS-205. Monitor CDS Runtime Status & Create Wavefront Alerts -- Stg]]
	- Progress with updated ETA noted on personal documentation and ticket
	- This sprint focuses on completing testing queries that is created on wavefront vmc-stg
		- Alert is titled: wavefront-pop-cloud-domain-service-failed
	- Plan is to leave alert in stg for the time being while we wait for production
	- Roll out is planned for 2 weeks after 11.08.22
- Conmon
	- Discussions with Khalil, Chenchen, and reached out to Daniel Ma from `#vmc-govcloud-cve-triage`
	- Initially blocked by local sddc-worker image, resolved, then blocked by authentication issue after scanning image with twistcli
		- Error claims twistcli version is not supported and requires updating, but is the most up-to-date version
		- Awaiting Khalil to respond with authentication before attempting to scan again
- RTS Scripts
	- Met with Rohith for a brief TOI on RTS scripts
		- [[TOI for RTS Script, 10.27.2022]]
- Planned
	- Starting on [[VPOD-7360. PHSA-2022-3.0-0480 |CVSS 7.50 | expat]] as soon as possible after blocker is resolved
	- Meeting with Ankit to run through and understand sddc bringup functional spec before end of week
	- Meeting with Rohith to run through runbook for triaging sddc bringup failures before end of week
- Other

	* Transferred data, setup, config, information from M1 Mac to Intel Mac
		* Intel Mac successfully builds and runs sddc-worker locally

## 10.27.22

[[CDS-217. VMC-A Bring-Up Unit Tests for SDDC]]
- Meetings and reach-outs throughout the week with Linshan, Yufeng, and Jiang for the discovery phase of task to understand metrics, queries, and wavefront
	- Dove deeper into the numerous metrics that seemed likely possible to monitor cds tenant services' health
		- docker_container_status.exitcode
		- docker_container_status.oomkilled
		- docker.cloud-domain-service_update.is_successful
		- docker_container_status.pid
- For this sprint, to focus on query ondocker_container_status.pid and vmc.sddc.status
- For next sprint, to broaden out and explore other metrics such as memory, cpu usage, etc.
- Conmon
- TOI from ChenChen on how to proceed with tickets
	- sddc-worker tested out and built both production version and for conmon
- Blockers
	- Facing rancher and docker issue with sddc-worker local
	- [[Notes on Enabling SDDC-Worker for x86 Architecture]]
	- Reached out to Helen for assistance

## 10.14.22

- [[CDS-217. VMC-A Bring-Up Unit Tests for SDDC]]
	- Code ran into pre and post-commit pipeline issues
	- post-commit pipeline failed even after undoing the changes, however, errors were unrelated to the code but the sonar cube scan
		- [[VPOD-7275. Investigate Why Pod Post-Commit Pipeline Is Failing in Sonar Cube]]
			- Reported the issue with Shailesh and created a ticket
			- Temporarily removed sonar cube scan from pipeline steps
			- Resolved all issues, adding back the tests that were previously removed due to a bug resolved by Anitha
	- Ticket is now closed and complete
- [[CDS-206. Validate Support for Pop Self-Signed Certificates in IL6 & Local SS-Backend]]
	- Begin the setup for local ss-backend

## 10.07.22

- [CDS-209](https://jira.eng.vmware.com/browse/CDS-209)
	- Dived into ticket to ensure SOS logs (streamed to stdout) on POP are outputted on LINT
		- Submitted access for LINT: VMC vRLiC For SAAS
	- Validated logs from pop tenant service are properly reflected in LINT when streamed to stdout
- [[CDS-217. VMC-A Bring-Up Unit Tests for SDDC]]
	- Continued working with Rohith to refactor code on unit tests
	- Shipped code but ran into pipeline issues, needing to undo changelist from depot for the time being
	- Triage testing methods and re-submitting code

## 09.30.22

- [[CDS-217. VMC-A Bring-Up Unit Tests for SDDC]]
	- Continuing work with Rohith, refactoring code, resolving issues for unit tests
	- Met with Rohith to discuss blocker on code coverage on covering wait_for_bootstrap_task function for unit test
	- 100% code coverage on the following files:
		- [//depot/bora/main/apps/pod/src/test/test_bootstrap_lib.py](https://reviewboard.eng.vmware.com/r/1936178/diff/13/#3)
		- [//depot/bora/main/apps/pod/src/test/test_cds_bringup_config.py](https://reviewboard.eng.vmware.com/r/1936178/diff/13/#2)
		- [//depot/bora/main/apps/pod/src/test/test_pod_lib.py](https://reviewboard.eng.vmware.com/r/1936178/diff/13/#1)
		- [//depot/bora/main/apps/pod/src/test/test_task_manager.py](https://reviewboard.eng.vmware.com/r/1936178/diff/13/#0)
		- [//depot/bora/main/apps/pod/src/test/test_sddc_bringup_v1_spec_parser.py](https://reviewboard.eng.vmware.com/r/1936178/diff/10/#1)
		- Removed [//depot/bora/main/apps/pod/src/test/test_sddc_bringup_v1_spec_parser.py](https://reviewboard.eng.vmware.com/r/1936178/diff/10/#1) from future diffs due to unrelated test failure
	- Reached out to Anitha Ganesha to fix the issue
	- Began refactoring submitted code
	- Met with Rohith for guidance on better unit testing practices, explanation on code review, how to refactor code, etc.
	- Reached out to Jianping Yang for VMC GovCloud access to gain access for task in enabling sddc-worker for VMC GovCloud
	- Submitted access for csp.local account on Gov Cloud Staging

## 09.23.22

* Setup and went through SSH on POP, utilizing Postman API's following pod-service repo readme
	* After understanding and playing with docker mounts, I wanted to create a new SDDC to reset the POP directory, but SDDC creation was blocked for me throughout the week
* Continued working on unit tests for Linshan's bringup workflow changes
	* Blocked on fully code covering one function, waiting to sync with Rohith to discuss
* PTO from 09.21.22-09.23.22

## 09.09.22

* 09.02.22
	* Working with Uday to follow up a thread with Yufeng to pursue this request
	* Received clearer communication with Yufeng and Uday on bundling CDS Tenant services with POP SOS logs
	* 09.09.22
		* Investigating instructions
* Started working on unit testing for Linshan's bringup workflow changes
	* Syncs and meetings with Rohith to go over blockers, code reviews
* Blockers
	* dbc had permission issues with unit testing commands with both unit test scripts
		* Received help from slack channel: `#dbc`
	* rbt post and post-review command would not work with dbc
		* Fixed through slack channel: `#reviewboard`
	* Still facing some workflow issues with Perforce on mac and dbc

## 09.02.22

* Shadowed Rohith regarding the Jenkins cds-post-commit-pipeline task
* TOI with Rohith on python unit testing (explaining code coverage)
* Worked with Rohith in resolving vbazel issues within perforce
* Setting up sddc-worker on a remote linux vm due to M1
	* [[Documentation for SDDC-Worker With VMware Horizon Cloud Host Setup (M1 Architecture)]]
	* Figuring out how to port forward requests from local machine to linux vm
* Setup local unit testing on pyCharm
	* Waiting on Linshan to merge bringup changes before writing unit testing code
* Initially communicated with Yufeng regarding registering CDS Tenant Service as part of the SOS bundle log collection, Yufeng communicated that our proposal was not supported

## 08.26.22

* **Onboarding (Continue)**
	* Received all required accesses for onboarding
	* Waiting on VM to setup sddc-worker because of M1 chip
	* Currently starting on updating jenkins pod-postcommit-cds-pipeline to automatically update CDS branch with latest POD CLN every 24 hours

## 08.19.22

* **Onboarding**
	* Finished setting up Perforce, DBC, P4V
	* Still waiting on access for service roles for VMC PROD and STG & LINT Access
	* Played around with SDDC (VMC on AWS portion of onboarding guide)
	* Cloned pod-services and finishing up rancher (docker) setup with sandbox build
		* Learning more about docker
	* Sync-up with Linshan next week for code deep dive
	* Want to finish more of POD Team Knowledge Resources videos
	* Want to get familiar with workflow and build system
