---
title: "Pod Conmon 🚓"
tags:
  - pod/2022/10/27
  - pod/topic/govcloud/conmon
  - status/active
  - task
date created: Tuesday, November 8th 2022, 12:45:24 pm
date modified: Wednesday, November 9th 2022, 8:35:07 am
---

## Authentication

> From Khalil, 2022-11-03

### Password

```
gKGFwcGxpZXMgdG8gYWxsIGN
```

### Scan Images Shortcut Command

```
sudo ./twistcli images scan --details --address https://twistlock-corp-psco01-stg-gov-psco01-us-gov-west-1.vdp-int-stg.vmware.com/ --user vmc-sddc-worker --password gKGFwcGxpZXMgdG8gYWxsIGN sddc-worker-sddc-worker:latest
```

---

## TOI on Conmon

<https://VMware.zoom.us/rec/share/347lPRLML47HwCZ5QIJ2_hQJcTeTEJVvyMTf1RBfz0GtCuia4TmNUAuBHYgeAv8z.z6wUAxqI09CgIu2t?startTime=1666730027000>

- Passcode: nAc+z1Hw

## Useful Slack Channels

`#vmc-govcloud-cve-triage`

`#pod-conmon-response`

## How to Approach Conmon Tickets

- First, read through the description of your issue. Most of the time, it will provide a solution that informs you of the package/dependency that needs to be changed
	- Most of the time, the fix is to bump the version of some library that is within sddc-worker, and most of the time, the ticket will inform you of the exact version to change it to
- If the ticket provides no meaningful information, look at the other related issues that are blocking your ticket
	- Usually the parent tickets can provide clues on how to triage your issue
- If you are still stuck, reach out for help at `#vmc-govcloud-cve-triage`
- Upon scanning the sddc-worker image with twistcli - if your ticket number **does not** show up in the response, you have resolved your issue
- Make sure to properly merge your issue
- ==Wait until your changes are pushed onto production before resolving your ticket==

## Scanning Images with Twistcli

[Twistcli documentation, confluence](https://confluence.eng.vmware.com/display/VMwareGS/How+to+scan+images+with+twistcli)

1. First, download the binary from [here](https://confluence.eng.vmware.com/pages/viewpage.action?spaceKey=VDPDOCS&title=15.++Container+Scanning). After downloading the binary, run it. Keep note of where you downloaded the binary to as well as the binary name. That is where you'll be routing the command to scan your sddc-worker image.

```
./twistcli
```

- If you face a shell permission error, grant the binary the necessary permissions:

```
chmod u+x ./twistcli
```

- If your mac prompts that there is a security issue, dismiss it and then go into your System Settings -> Privacy & Security -> and Allow "twistcli" to run

![[CleanShot 2022-11-03 at <14.55.44@2x.png>]]

- After granting permission, retry again
- Scan the image with the following command:

```
sudo twistcli images scan --details --address <twistcli-login-link> --password <password> sddc-worker-sddc-worker:latest
```

---

## FAQ

Q1. I was assigned a ticket that has not been started yet, but upon scanning the image, I noticed that the fix has already been applied. The snapshot does not include my ticket number. How should I update my ticket?

- Find the corresponding ticket that contained the fix to your issue. Paste that ticket's link into your ticket's description. State in your description that a fix has already been made. You can choose to attach a snapshot of your terminal if you want. Do not mark your ticket as resolved until the fix is in production.

Q2. When I try to scan the image, I face this error:

```
Status: 400 Bad Request
GET <https://twistlock-csp01-dev-gov-us-gov-west-1.vdp-int-dev.vmware.com/api/v22.06/authenticate/identity-redirect-url?type=prismaCloud> failed.
```

![[Pod Conmon 🚓.png]]

- Verify that you are using the correct username and password that was provided to you. Make sure that the twistcli login link you are using in your command is updated and is the same as the one that is provided [here](https://confluence.eng.vmware.com/display/VMwareGS/How+to+scan+images+with+twistcli).
- Reach out to `#vmc-govcloud-cve-triage`.

Q3. How do I request for LastPass access?

- LastPass access is granted through AccessNow+. Follow instructions provided [here](https://myvmware.workspaceair.com/SAAS/API/1.0/GET/apps/launch/app/e47de334-f8ed-4355-987a-c9e36322868e?appLaunchId=_a64cb11c69fc21073b3d8cbb9358cf46).